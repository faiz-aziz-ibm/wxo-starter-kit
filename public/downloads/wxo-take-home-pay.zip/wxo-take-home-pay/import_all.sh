#!/usr/bin/env bash
# Import the whole take-home-pay reference project, in dependency order.
# Run from the project root, against an activated ADK environment:
#   orchestrate env activate <your-env>
#   ./import_all.sh
set -euo pipefail

echo "1/5  Importing tools..."
orchestrate tools import -k python -f tools/calculate_income_tax.py
orchestrate tools import -k python -f tools/calculate_national_insurance.py
orchestrate tools import -k python -f tools/calculate_pension_relief.py

echo "2/5  Importing the salary-sacrifice workflow (as a tool)..."
orchestrate tools import -k flow -f flows/salary_sacrifice_approval.py

echo "3/5  Importing the knowledge base..."
orchestrate knowledge-bases import -f knowledge_base/tax_policy_kb.kb.yaml

echo "4/5  Importing specialist agents (before the supervisor)..."
orchestrate agents import -f agents/income_tax_agent.agent.yaml
orchestrate agents import -f agents/ni_agent.agent.yaml
orchestrate agents import -f agents/pension_agent.agent.yaml

echo "5/5  Importing the supervisor..."
orchestrate agents import -f agents/payroll_supervisor.agent.yaml

echo
echo "Done. Chat with it:"
echo "  orchestrate chat ask --agent-name payroll_supervisor"
