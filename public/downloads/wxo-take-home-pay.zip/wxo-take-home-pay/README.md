# Take-Home Pay - a watsonx Orchestrate reference project

A complete, importable wxO project that answers UK take-home-pay questions. It
shows how the pieces of an agentic system fit together: **deterministic Python
tools**, **specialist agents**, a **supervisor** that routes between them, an
**agentic workflow** with a human approval step, and a **knowledge base** that
grounds the explanations.

It is the fully built-out version of the running example in the Learning Roadmap.

## Architecture

```
                         payroll_supervisor            (routes by intent)
                          /        |        \
            income_tax_agent   ni_agent   pension_agent
                   |               |            |    \
         calculate_income_tax   calc_NI   calc_pension   salary_sacrifice_approval
                   |                                          (workflow: validate
             tax_policy_kb  (grounds bands & thresholds)       -> manager approval
                                                               -> record)
```

- **Tools** do the maths. LLMs are unreliable at arithmetic, so every figure comes
  from a tool, never the model.
- **Specialists** each own one domain and 1-2 tools (well within the 3-7 rule).
- **The supervisor** never calculates - it routes to a specialist and, for a full
  take-home figure, gathers income tax + NI (+ pension impact) and sums them.
- **The workflow** handles the one deterministic, human-in-the-loop step
  (approving a salary-sacrifice change) - not a job for a free-reasoning agent.
- **The knowledge base** grounds the specialists' explanations of bands/thresholds.

## Layout

```
tools/            calculate_income_tax / _national_insurance / _pension_relief
flows/            salary_sacrifice_approval.py  (imported as a tool)
agents/           income_tax_agent, ni_agent, pension_agent, payroll_supervisor
knowledge_base/   tax_policy_kb.kb.yaml + docs/tax_bands_2024_25.txt
import_all.sh     imports everything in dependency order
```

## Run it

```bash
pip install -r requirements.txt
orchestrate env activate <your-env>      # see the Deploy chapter of the Starter Kit
./import_all.sh                          # or run the commands yourself
orchestrate chat ask --agent-name payroll_supervisor
```

Try: *"What's my take-home on GBP 45,000?"*, *"How much NI on GBP 60,000?"*,
*"What would a GBP 5,000 pension sacrifice save me on GBP 55,000?"*

## Honest notes

- **Import order matters:** tools and the knowledge base must exist before the
  agents that reference them, and the specialists before the supervisor. The
  script does this for you.
- **Tax figures are illustrative** for the 2024/25 rUK tax year - confirm against
  current HMRC rates before production use. The logic is deliberately simple and
  well commented so you can swap in your own country's bands.
- **Workflows use newer ADK APIs.** The flow follows the current docs; if your ADK
  version differs, check the flow-builder reference for the exact import paths and
  method names.
- **No secrets in code.** These tools are self-contained. When a tool needs an
  external system, use wxO Connections (see the Build chapter) - never hard-code keys.

Curated for the watsonx Orchestrate Starter Kit by Faiz Aziz - faiz.aziz@ibm.com.
