from ibm_watsonx_orchestrate.agent_builder.tools import tool


@tool
def calculate_national_insurance(annual_salary: float) -> str:
    """
    Calculates employee Class 1 National Insurance for a gross annual salary.

    Illustrative 2024/25 thresholds: 8% between the primary threshold
    (GBP 12,570) and the upper earnings limit (GBP 50,270), then 2% above.

    Args:
        annual_salary (float): Gross annual salary in GBP.

    Returns:
        str: A one-line summary of the National Insurance due for the year.
    """
    primary_threshold = 12570.0
    upper_earnings_limit = 50270.0

    main = min(max(annual_salary - primary_threshold, 0.0),
               upper_earnings_limit - primary_threshold) * 0.08
    upper = max(annual_salary - upper_earnings_limit, 0.0) * 0.02
    ni = main + upper

    return f"National Insurance on GBP {annual_salary:,.0f}: GBP {ni:,.2f} for the year."
