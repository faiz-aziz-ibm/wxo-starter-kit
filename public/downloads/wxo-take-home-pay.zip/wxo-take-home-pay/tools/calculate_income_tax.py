from ibm_watsonx_orchestrate.agent_builder.tools import tool


@tool
def calculate_income_tax(annual_salary: float) -> str:
    """
    Calculates UK income tax (England, Wales & N. Ireland) for a gross annual salary.

    Rates are illustrative for the 2024/25 tax year — confirm current HMRC rates
    before relying on the figure in production.

    Args:
        annual_salary (float): Gross annual salary in GBP (e.g. 45000).

    Returns:
        str: A one-line summary of the income tax due for the year.
    """
    # Personal allowance, tapered by £1 for every £2 of income over £100,000.
    allowance = 12570.0
    if annual_salary > 100000.0:
        allowance = max(0.0, 12570.0 - (annual_salary - 100000.0) / 2.0)

    taxable = max(0.0, annual_salary - allowance)

    tax = 0.0
    # 20% basic rate on the first £37,700 of taxable income.
    basic = min(taxable, 37700.0)
    tax += basic * 0.20
    # 40% higher rate on taxable income from £37,700 up to £112,570.
    higher = min(max(taxable - 37700.0, 0.0), 112570.0 - 37700.0)
    tax += higher * 0.40
    # 45% additional rate on the remainder.
    additional = max(taxable - 112570.0, 0.0)
    tax += additional * 0.45

    return (
        f"Income tax on GBP {annual_salary:,.0f}: GBP {tax:,.2f} "
        f"(personal allowance GBP {allowance:,.0f})."
    )
