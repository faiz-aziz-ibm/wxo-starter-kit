from ibm_watsonx_orchestrate.agent_builder.tools import tool


@tool
def calculate_pension_relief(annual_salary: float, annual_contribution: float) -> str:
    """
    Estimates the tax + NI saving from a salary-sacrifice pension contribution.

    Salary sacrifice reduces gross pay, so the saving is the contribution
    multiplied by the employee's marginal income-tax and NI rates.

    Args:
        annual_salary (float): Gross annual salary in GBP, before sacrifice.
        annual_contribution (float): Yearly pension contribution in GBP.

    Returns:
        str: A one-line summary of the estimated saving and net cost.
    """
    # Marginal income-tax rate.
    if annual_salary > 125140.0:
        income_rate = 0.45
    elif annual_salary > 50270.0:
        income_rate = 0.40
    elif annual_salary > 12570.0:
        income_rate = 0.20
    else:
        income_rate = 0.0

    # Marginal NI rate.
    ni_rate = 0.02 if annual_salary > 50270.0 else (0.08 if annual_salary > 12570.0 else 0.0)

    saving = annual_contribution * (income_rate + ni_rate)
    net_cost = annual_contribution - saving

    return (
        f"A GBP {annual_contribution:,.0f} salary-sacrifice contribution saves about "
        f"GBP {saving:,.2f} in tax + NI, so the net cost is about GBP {net_cost:,.2f}."
    )
