"""Agentic workflow: validate a pension salary-sacrifice request, get manager
approval (human-in-the-loop), then record it. Imported as a tool with:

    orchestrate tools import -k flow -f flows/salary_sacrifice_approval.py
"""
from pydantic import BaseModel

from ibm_watsonx_orchestrate.agent_builder.tools import tool
from ibm_watsonx_orchestrate.flow_builder.flows import Flow, flow
from ibm_watsonx_orchestrate.flow_builder.flows.constants import START, END
from ibm_watsonx_orchestrate.flow_builder.types import UserFieldKind


class SacrificeRequest(BaseModel):
    employee_id: str
    annual_contribution: float


@tool
def validate_sacrifice(annual_contribution: float) -> str:
    """
    Checks a pension salary-sacrifice request is within the annual allowance.

    Args:
        annual_contribution (float): Proposed yearly contribution in GBP.

    Returns:
        str: "ok" if allowed, otherwise a short reason it is blocked.
    """
    if annual_contribution <= 0:
        return "blocked: contribution must be a positive amount"
    if annual_contribution > 60000:
        return "blocked: exceeds the GBP 60,000 annual allowance"
    return "ok"


@tool
def record_pension_change(employee_id: str, annual_contribution: float) -> str:
    """
    Records an approved pension salary-sacrifice change.

    Args:
        employee_id (str): The employee's ID.
        annual_contribution (float): The approved yearly amount in GBP.

    Returns:
        str: A confirmation reference.
    """
    return f"Recorded: {employee_id} now sacrificing GBP {annual_contribution:,.2f}/yr into pension."


@flow(
    name="salary_sacrifice_approval",
    description="Validates a pension salary-sacrifice request, gets manager approval, then records it.",
    input_schema=SacrificeRequest,
    output_schema=str,
)
def build_flow(aflow: Flow = None) -> Flow:
    validate_node = aflow.tool(validate_sacrifice)

    # Human-in-the-loop: a sub-flow that asks a manager to approve.
    approval = aflow.userflow()
    approve_node = approval.field(
        direction="input",
        name="approved",
        display_name="Approve request?",
        kind=UserFieldKind.Text,
        text="Manager: approve this salary sacrifice? (yes/no)",
    )
    approval.edge(START, approve_node)
    approval.edge(approve_node, END)

    record_node = aflow.tool(record_pension_change)

    aflow.sequence(START, validate_node, approval, record_node, END)
    return aflow
