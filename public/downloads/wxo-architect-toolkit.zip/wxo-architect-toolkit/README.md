# watsonx Orchestrate — Architect Toolkit (`.bob`)

Everything you need to turn your AI coding assistant into a **watsonx Orchestrate Agent Architect**.
Curated by **Faiz Aziz** · faiz.aziz@ibm.com · Data & AI Delivery Consultant, IBM Expert Labs.

Drop the `.bob` folder into the root of your project and your assistant gains:

- **WXO Agent Architect mode** — a custom persona ("Bob") tuned for authoring wxO agents, tools, flows, knowledge bases and connections.
- **Two MCP servers** wired up:
  - `watsonx-orchestrate-adk-docs` — the official wxO documentation MCP server (searchable docs).
  - `watsonx-orchestrate-adk` — the ADK MCP server that can list/create agents, tools and resources in your environment.
- **Four wxO skills** — `solution-architect`, `sop-builder`, `wxo-builder`, `wxo-analyzer` — covering the closed loop from business problem → SOP → implementation → documentation.

## What's inside

```
.bob/
├── custom_modes.yaml     # The WXO Agent Architect mode
├── mcp.json              # ADK docs + ADK MCP server config
└── skills/
    ├── solution-architect/
    ├── sop-builder/
    ├── wxo-builder/
    └── wxo-analyzer/
```

## Setup

1. **Copy `.bob/` into your project root.**
2. **Prerequisites:** install [`uv`](https://docs.astral.sh/uv/) (provides `uvx`) and the ADK:
   ```bash
   pip install ibm-watsonx-orchestrate
   ```
3. **Point `mcp.json` at a working directory.** Set `WXO_MCP_WORKING_DIRECTORY` to the folder the
   ADK MCP server may read/write (import/export needs this — it is blocked by default for safety):
   ```json
   "env": { "WXO_MCP_WORKING_DIRECTORY": "/absolute/path/to/your/project" }
   ```
4. **Authenticate the ADK** against your environment (see the Deploy chapter of the Starter Kit):
   ```bash
   orchestrate env add -n my-wxo-env -u <your-service-instance-url>
   orchestrate env activate my-wxo-env
   ```
5. **Open your assistant, select the WXO Agent Architect mode, and start building.**

## The skills at a glance

| Skill | Turns… | …into |
| --- | --- | --- |
| solution-architect | a business problem | a structured solution architecture |
| sop-builder | a workflow (BPMN / n8n / Langflow) | a business-readable SOP |
| wxo-builder | an SOP or prompt | a working wxO implementation (agents, tools, flows, KBs) |
| wxo-analyzer | an existing wxO project | documentation + anti-pattern analysis |

Closed loop: **solution-architect → sop-builder → wxo-builder → wxo-analyzer**.

---

Unofficial community toolkit. Always confirm behaviour against the official
[wxO developer docs](https://developer.watson-orchestrate.ibm.com).
